package com.example.api_restaurant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
